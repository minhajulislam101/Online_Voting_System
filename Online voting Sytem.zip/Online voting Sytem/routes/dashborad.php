<html>
    <head>
        <title> Online system</title>
</head>
            <body>
           <button>Back</button>
           <button>Logout</button>
                <h1>Online voting system</h1>
                <hr>
                <div id="Profile"></div>
                <div id="Gruop"></div>
                
            </body>
 
</html>